const AWS = require("aws-sdk");
const util = require("../utils/util");
const passwordHash = require("bcryptjs");
const sns = new AWS.SNS();

AWS.config.update({
  region: "us-east-1",
});

const dynamoDB = new AWS.DynamoDB.DocumentClient();
const signupTable = "cloudterm";

async function signup(userInfo) {
  const name = userInfo.name;
  const email = userInfo.email;
  const password = userInfo.password;

  if (!name || !email || !password) {
    return util.buildResponse(401, {
      message: "All fields are required",
    });
  }

  const dbUser = await getUser(email);
  if (dbUser && dbUser.email) {
    return util.buildResponse(401, {
      message:
        "Email already exists! Please Login or Signup with a different email.",
    });
  }

  const encryptedPassword = passwordHash.hashSync(password.trim(), 10);
  const user = {
    name: name,
    email: email,
    password: encryptedPassword,
  };

  async function subscribeUserToTopic(email) {
    const topicArn = "arn:aws:sns:us-east-1:128210752542:TermProject";
    const params = {
      Protocol: "Email",
      TopicArn: topicArn,
      Endpoint: email,
    };

    try {
      await sns.subscribe(params).promise();
      console.log(`Subscribed user ${email} to the SNS topic successfully.`);
      return true;
    } catch (error) {
      console.error(`Error subscribing user ${email} to the SNS topic:`, error);
      throw error;
    }
  }

  const saveUserResponse = await saveUser(user);
  if (!saveUserResponse) {
    // console.log(error);
    return util.buildResponse(503, { message: "Error saving the user" });
  }

  try {
    await subscribeUserToTopic(email);
  } catch (error) {
    console.error("Error subscribing user to SNS topic:", error);
  }

  return util.buildResponse(200, { name: name });
}

async function getUser(email) {
  const params = {
    TableName: signupTable,
    Key: {
      email: email,
    },
  };

  try {
    const response = await dynamoDB.get(params).promise();
    return response.Item;
  } catch (error) {
    console.log("Error getting the user email");
    console.error(error);
    throw error;
  }
}

async function saveUser(user) {
  const params = {
    TableName: signupTable,
    Item: user,
  };

  try {
    await dynamoDB.put(params).promise();
    return true;
  } catch (error) {
    console.log("Error saving the user details");
    console.error(error);
    throw error;
  }
}

module.exports.signup = signup;
