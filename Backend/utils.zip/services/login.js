const AWS = require("aws-sdk");
const util = require("../utils/util");
const passwordHash = require("bcryptjs");
const auth = require("../utils/auth");

AWS.config.update({
  region: "us-east-1",
});

const dynamoDB = new AWS.DynamoDB.DocumentClient();
const signupTable = "cloudterm";

async function login(user) {
  const email = user.email;
  const password = user.password;

  if (!user || !email || !password) {
    return util.buildResponse(401, {
      data: {
        message: "Email and password are required",
      },
    });
  }
  const dbUser = await getUser(email);
  if (!dbUser || !dbUser.email) {
    return util.buildResponse(403, {
      data: {
        message: "User does not exist! Please enter correct email or Signup",
      },
    });
  }

  if (!passwordHash.compareSync(password, dbUser.password)) {
    return util.buildResponse(403, { data: { message: "Invalid password" } });
  }

  const userInfo = {
    email: dbUser.email,
    name: dbUser.name,
  };

  const token = auth.generateToken(userInfo);

  const response = {
    user: userInfo,
    token: token,
  };
  return util.buildResponse(200, email);
}

async function getUser(email) {
  const params = {
    TableName: signupTable,
    Key: {
      email: email,
    },
  };

  try {
    const response = await dynamoDB.get(params).promise();
    return response.Item;
  } catch (error) {
    console.log("Error getting the user email");
    console.error(error);
    throw error;
  }
}

module.exports.login = login;
