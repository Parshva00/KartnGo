const jwt = require("jsonwebtoken");

function generateToken(userInfo) {
  if (!userInfo) {
    return null;
  }

  return jwt.sign(userInfo, process.env.JWT_SECRET, {
    expiresIn: "1h",
  });
}

function verifyToken(name, token) {
  return jwt.verify(token, process.env.JWT_SECRET, (error, response) => {
    if (error) {
      return {
        verified: false,
        message: "Invalid auth token. Retry Login",
      };
    }

    if (response.name !== name) {
      return {
        verified: false,
        message: "Invalid User. Please retry",
      };
    }

    return {
      verified: true,
      message: "verified",
    };
  });
}

module.exports.generateToken = generateToken;
module.exports.verifyToken = verifyToken;
