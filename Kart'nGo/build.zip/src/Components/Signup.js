import React, { useState } from "react";
import { Box, Button, TextField, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Navbar from "./Navbar";
import APIs from "../constants";

// const signupURL =
//   "https://71iqjioice.execute-api.us-east-1.amazonaws.com/prod/signup";

const Signup = () => {
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [isName, setIsName] = useState(true);

  const [email, setEmail] = useState("");
  const [isEmailValid, setIsEmailValid] = useState(true);

  const [password, setPassword] = useState("");
  const [isPasswordValid, setIsPasswordValid] = useState(true);

  const [error, setErrormessage] = useState("");
  const [message, setMessage] = useState("");

  const handleNameChange = (event) => {
    const value = event.target.value;
    setName(value);
    setIsName(value.length > 2); // Example validation condition
  };

  const handleEmailChange = (event) => {
    const value = event.target.value;
    setEmail(value);
    setIsEmailValid(validateEmail(value));
  };

  const handlePasswordChange = (event) => {
    const value = event.target.value;
    setPassword(value);
    setIsPasswordValid(validatePassword(value));
  };

  const validateEmail = (email) => {
    // Regular expression pattern for email validation
    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return pattern.test(email);
  };

  const validatePassword = (password) => {
    // Regular expression pattern for password validation
    const pattern =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[a-zA-Z\d!@#$%^&*]{8,18}$/;
    return pattern.test(password);
  };

  const handleSignUp =  async (event) => {
    event.preventDefault();
    if (name === "" || email === "" || password === "") {
      setErrormessage("Please fill in all required fields");
      console.log("Please fill in all required fields");
      return; // Prevent form submission
    }

    const user = {
      name: name,
      email: email,
      password: password,
    };

     await axios
      .post(APIs.SIGNUP, user)
      .then((response) => {
        setMessage("Signup Successful");

        console.log(response.data);
        navigate("/login");
      })
      .catch((error) => {
        if (
          error.response &&
          (error.response.status === 401 || error.response.status === 403)
        ) {
          setMessage(error.response.data.message);
        } else {
          setMessage("Error during signing up", error);
        }

        console.log("Error while signing up", error);
        console.error(error);
      });
  };

  return (
    <div>
      <form>
        <Navbar />
        <Box
          display="flex"
          flexDirection={"column"}
          maxWidth={400}
          margin={"auto"}
          marginTop={5}
          marginBottom={5}
          padding={2}
          borderRadius={5}
          boxShadow={"0px 0px 10px #ccc"}
          sx={{
            ":hover": {
              boxShadow: "0px 5px 10px #ccc",
            },
          }}
        >
          <Typography
            variant="h3"
            padding={2}
            textAlign="center"
            sx={{ fontSize: 24, fontFamily: "cursive" }}
          >
            Sign up
          </Typography>
          {error && (
            <Typography variant="body1" color="error" align="center">
              {error}
            </Typography>
          )}
          <Typography
            variant="h6"
            padding={1}
            sx={{ fontSize: 16, fontFamily: "cursive" }}
          >
            Username
          </Typography>
          <TextField
            id="username"
            name="name"
            value={name}
            type={"text"}
            variant="outlined"
            placeholder="e.g: GenZ"
            InputProps={{
              style: {
                borderRadius: "10px",
                height: "46px",
              },
            }}
            onChange={handleNameChange}
            error={!isName}
            helperText={!isName ? "Username is required" : ""}
            pattern="[a-zA-Z0-9_]+"
            required
          />
          <Typography
            variant="h6"
            padding={1}
            sx={{ fontSize: 16, fontFamily: "cursive" }}
            textAlign={"left"}
          >
            Email
          </Typography>
          <TextField
            name="email"
            type="Email"
            variant="outlined"
            placeholder="e.g: genz@abc.com"
            value={email}
            InputProps={{
              style: {
                borderRadius: "10px",
                height: "46px",
                fontFamily: "cursive",
              },
            }}
            onChange={handleEmailChange}
            error={!isEmailValid}
            helperText={!isEmailValid ? "Invalid email format" : ""}
            required
          />
          <Typography
            variant="h6"
            sx={{ fontSize: 16, fontFamily: "cursive" }}
            padding={1}
            textAlign={"left"}
          >
            Create Password
          </Typography>

          <TextField
            name="password"
            sx={{ borderRadius: 5 }}
            type="password"
            variant="outlined"
            value={password}
            InputProps={{
              style: {
                borderRadius: "10px",
                height: "46px",
              },
            }}
            onChange={handlePasswordChange}
            error={!isPasswordValid}
            helperText={!isPasswordValid ? "Invalid password format" : ""}
            required
          />
          <Button
            marginTop={3}
            onClick={handleSignUp}
            sx={{
              borderRadius: 10,
              paddingTop: 1.5,
              paddingBottom: 1.5,
              marginBottom: 2,
              marginTop: 4,
              backgroundColor: "black",
              textAlign: "center",
              fontSize: 14,
              fontFamily: "cursive",
            }}
            variant="contained"
          >
            Sign up
          </Button>

          <Typography
            variant="h5"
            padding={1}
            textAlign={"center"}
            sx={{ fontFamily: "cursive" }}
          >
            Or
          </Typography>
          <Typography
            variant="h6"
            // padding={1}
            sx={{ fontSize: 20, marginLeft: 2, fontFamily: "cursive" }}
            textAlign={"left"}
          >
            Already have an account?
            <Button
              onClick={() => {
                navigate("/login");
              }}
              marginTop={3}
              style={{ height: "25px" }}
              sx={{
                borderRadius: 5,
                marginLeft: 2,
                fontSize: 18,
                fontFamily: "cursive",
              }}
            >
              Login
            </Button>
          </Typography>
        </Box>
      </form>
    </div>
  );
};
export default Signup;
